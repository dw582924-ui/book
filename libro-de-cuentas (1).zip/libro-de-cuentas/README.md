# Libro de cuentas

App personal de manejo financiero: ingresos, gastos, deudas, presupuesto y ahorros, con registro mensual y gráficos.

## Correr en local

```bash
npm install
npm run dev
```

## Compilar para producción

```bash
npm run build
```

Esto genera la carpeta `dist/`, lista para desplegar en Vercel, Firebase Hosting, Netlify o GitHub Pages.

## Datos

Los datos se guardan en `localStorage` del navegador (no hay backend). Esto significa que:
- Los datos viven solo en el navegador/dispositivo donde se usa la app.
- Si se borra el caché del navegador, se pierden los datos.
- No hay sincronización entre dispositivos.

Si más adelante se quiere persistencia real (multi-dispositivo, respaldo), se puede conectar a Supabase.
